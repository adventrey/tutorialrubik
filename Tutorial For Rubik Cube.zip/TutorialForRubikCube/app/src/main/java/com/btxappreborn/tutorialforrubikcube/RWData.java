package com.btxappreborn.tutorialforrubikcube;

public class RWData {
    private int gambar;

    public int getGambar() {
        return gambar;
    }

    public void setGambar(int gambar) {
        this.gambar = gambar;
    }

    public RWData(int gambar) {
        this.gambar = gambar;
    }

    public RWData() {
    }
}
