package com.btxappreborn.tutorialforrubikcube;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class BeginnerFragment extends Fragment {
    Button btnBCross, btnBWhiteCorner,btnBSecondLayers,btnBOll1,btnBOll2,btnBPll;

    public BeginnerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v = inflater.inflate(R.layout.fragment_beginner, container, false);
        btnBCross = v.findViewById(R.id.btnBCross);
        btnBWhiteCorner = v.findViewById(R.id.btnBWhiteCorner);
        btnBSecondLayers = v.findViewById(R.id.btnBSecondLayers);
        btnBOll1 = v.findViewById(R.id.btnBOLL1);
        btnBOll2 = v.findViewById(R.id.btnBOLL2);
        btnBPll = v.findViewById(R.id.btnBPLL);

        btnBCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerCrosFragment());
            }
        });
        btnBWhiteCorner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerWhiteCornersFragment());
            }
        });
        btnBSecondLayers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerSecondLayersFragment());
            }
        });
        btnBOll1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerOll1Fragment());
            }
        });
        btnBOll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerOll2Fragment());
            }
        });
        btnBPll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Ganti_Fragment_beginner(new BeginnerPllFragment());
            }
        });
        return v;
    }

    private void Ganti_Fragment_beginner(Fragment fragment) {

        getParentFragmentManager()
                .beginTransaction()
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .replace(R.id.fragmentPlaceBeginner, fragment)
                .commit();
    }
}